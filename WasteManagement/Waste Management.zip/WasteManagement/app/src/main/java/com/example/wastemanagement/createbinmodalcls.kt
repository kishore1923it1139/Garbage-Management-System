package com.example.wastemanagement

class createbinmodalcls(

    val id:String,
    val area:String, val locality:String, val landmark:String,
    val city:String,
    val Load:String, val cycle:String,val status:String
)
{
    constructor() :this("","","","","","","",""){

    }
}