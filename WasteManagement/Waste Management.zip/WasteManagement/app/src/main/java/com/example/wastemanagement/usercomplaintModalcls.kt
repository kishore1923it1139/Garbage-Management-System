package com.example.wastemanagement

class usercomplaintModalcls (val key:String,val name:String, val Areaname:String,val locality:String, val landmark:String,val city:String, val complaint:String)
{
    constructor() :this("","","","","","",""){

    }
}